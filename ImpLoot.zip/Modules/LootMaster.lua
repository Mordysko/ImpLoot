-------------------------------------------------
-- ImpLoot Loot Master
--
-- The corpse-side (and post-corpse "tracking") loot
-- queue. Populates itself from the real loot window,
-- decides each item's mode (Open Roll / Soft Reserve /
-- Loot Council) from the existing data modules, and
-- handles assignment -- via the real Master Loot API
-- while the corpse it came from is still open, falling
-- back to "just record the winner, trade manually"
-- once it isn't.
-------------------------------------------------

ImpLoot.LootMaster = {}

-------------------------------------------------
-- Roll Settings
--
-- Main Spec is a standard /roll (1-100); Off Spec is
-- the Off-Spec Roll button's 1-99 -- classified by the
-- roll's own upper bound, not a configurable threshold.
-------------------------------------------------

-------------------------------------------------
-- Settings Defaults
--
-- Persisted like everything else -- see Initialize.
-------------------------------------------------

ImpLoot.LootMaster.Defaults = {

    RollDuration = 30,
    PeriodicAnnounceInterval = 10,
    FinalCountdownThreshold = 5,

    AutoFinalizeOnTimeout = true,
    AutoAssignToRollWinner = true,
    AutoClearOnNewBoss = false,

    -- 0 (Poor) means no filtering at all -- every item
    -- that drops is queued, exactly like before this
    -- setting existed. Only items that would otherwise
    -- fall through to unassigned Open Roll are affected;
    -- see ShouldQueueItem below.
    MinimumQuality = 0,

    -- When true, /il <item> skips landing in the queue
    -- for a manual Announce click and immediately starts
    -- its roll/announcement instead -- whatever mode the
    -- item actually resolves to (SoftReserve, LootCouncil,
    -- or Open Roll), same as clicking Announce yourself
    -- would. Default false preserves the original /il
    -- behaviour of just adding it to the queue.
    ManualItemAutoRoll = false,

}

-------------------------------------------------
-- Legendary Assignment Confirmation
--
-- Legendary-quality items (Fragment of Val'anyr, etc.)
-- get an extra manual confirmation step before the
-- actual assignment happens -- a single misclick handing
-- one to the wrong person is a mistake that can't be
-- undone once it's looted/traded. Auto-Assign To Roll
-- Winner still picks the winner automatically for these;
-- it just pauses on this step instead of assigning
-- outright, same as a manual assignment would.
--
-- Deliberately NOT applied to every item -- that would
-- make Auto-Assign To Roll Winner largely pointless,
-- since every award would need a manual click-through
-- regardless. Scoped to quality 5 (Legendary) specifically.
-------------------------------------------------

StaticPopupDialogs["IMPLOOT_CONFIRM_LEGENDARY_ASSIGN"] = {

    text = "Award %s to %s?\n\nThis is a Legendary item and cannot be undone once assigned.",
    button1 = "Award",
    button2 = "Cancel",

    OnAccept = function(_, data)
        ImpLoot.LootMaster:Assign(data.QueueID, data.WinnerName)
    end,

    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,

}

-------------------------------------------------
-- Get Item Quality
--
-- Checks the addon's own raid database first (it's
-- pre-populated for every boss and doesn't depend on
-- the item having been seen/cached this session), then
-- falls back to the general item cache for anything not
-- in that database (e.g. a Trash/Extra Drops item, or
-- something from outside the addon's known raids).
-------------------------------------------------

function ImpLoot.LootMaster:GetItemQuality(itemID)

    local item = ImpLoot.Database:FindItemByID(itemID)

    if item and item.Quality then
        return item.Quality
    end

    local cached = ImpLoot.ItemCache:GetItem(itemID)

    if cached and cached.Quality then
        return cached.Quality
    end

    return nil

end

-------------------------------------------------
-- Get Player Item Count
--
-- How many times a player has already won a specific
-- item this session, per the resolution log. Built for
-- multi-piece Legendary components (Fragment of Val'anyr
-- and similar) -- shown next to a candidate's name so
-- whoever's assigning has that context in view at the
-- moment of the decision, rather than needing to
-- remember it or check the Summary window separately.
-------------------------------------------------

function ImpLoot.LootMaster:GetPlayerItemCount(playerName, itemID)

    local count = 0

    for _, logEntry in ipairs(self.Log or {}) do

        if logEntry.Winner == playerName and logEntry.ItemID == itemID then
            count = count + 1
        end

    end

    return count

end

-------------------------------------------------
-- Request Assign
--
-- The entry point every caller (manual Assign button,
-- Auto-Assign To Roll Winner, the no-rolls disenchant
-- path) should use instead of calling Assign directly.
-- Legendary items pause here for manual confirmation;
-- everything else assigns immediately exactly as before.
-------------------------------------------------

function ImpLoot.LootMaster:RequestAssign(queueID, winnerName)

    local entry = self:GetEntry(queueID)

    if not entry then
        return
    end

    local quality = self:GetItemQuality(entry.ItemID)

    if quality == 5 then

        StaticPopup_Show(
            "IMPLOOT_CONFIRM_LEGENDARY_ASSIGN",
            entry.ItemLink or entry.ItemID,
            winnerName,
            { QueueID = queueID, WinnerName = winnerName }
        )

        return

    end

    self:Assign(queueID, winnerName)

end

-------------------------------------------------
-- Assign Sole Reserver
--
-- The one-click path for a SoftReserve item nobody else
-- could possibly win (see SoftReserve:GetSoleReserver) --
-- announces the direct assignment to chat first, since
-- skipping the roll shouldn't also mean skipping letting
-- the raid know who got it and why, then goes through
-- the same RequestAssign path (legendary confirmation
-- included) as every other assignment.
-------------------------------------------------

function ImpLoot.LootMaster:AssignSoleReserver(queueID, winnerName)

    local entry = self:GetEntry(queueID)

    if not entry then
        return
    end

    ImpLoot.Announcements:Announce("SoleReserverAssigned", {
        item = entry.ItemLink,
        winner = winnerName,
    })

    self:RequestAssign(queueID, winnerName)

end

-------------------------------------------------
-- Roll Message Pattern
--
-- Matches WoW's own system message: "<Player> rolls
-- <roll> (<min>-<max>)".
-------------------------------------------------

local ROLL_PATTERN = "(.+) rolls (%d+) %((%d+)%-(%d+)%)"

-------------------------------------------------
-- Initialize
-------------------------------------------------

function ImpLoot.LootMaster:Initialize()

    ImpLootDB.LootMasterSettings = ImpLootDB.LootMasterSettings or {}

    for key, value in pairs(self.Defaults) do

        if ImpLootDB.LootMasterSettings[key] == nil then
            ImpLootDB.LootMasterSettings[key] = value
        end

    end

    self.Settings = ImpLootDB.LootMasterSettings

    ImpLootDB.LootMasterLog = ImpLootDB.LootMasterLog or {}
    self.Log = ImpLootDB.LootMasterLog

    self.Queue = {}
    self.NextQueueID = 1
    self.CurrentCorpseGUID = nil
    self.ActiveRollQueueID = nil

    local frame = CreateFrame("Frame")

    frame:RegisterEvent("LOOT_OPENED")
    frame:RegisterEvent("LOOT_CLOSED")
    frame:RegisterEvent("CHAT_MSG_SYSTEM")

    frame:SetScript("OnEvent", function(_, event, msg)

        if event == "LOOT_OPENED" then
            self:OnLootOpened()
        elseif event == "LOOT_CLOSED" then
            self:OnLootClosed()
        elseif event == "CHAT_MSG_SYSTEM" then
            self:OnChatMsgSystem(msg)
        end

    end)

    self.EventFrame = frame

    -------------------------------------------------
    -- Timer Ticking
    --
    -- Runs every 0.5s rather than every frame -- a
    -- roll countdown doesn't need frame-rate precision.
    -- OnTimerTick reads GetTime() itself rather than
    -- accumulating elapsed time, so it's also directly
    -- callable (e.g. from tests) without a real OnUpdate
    -- loop.
    -------------------------------------------------

    local tickFrame = CreateFrame("Frame")
    local sinceLastTick = 0

    tickFrame:SetScript("OnUpdate", function(_, delta)

        sinceLastTick = sinceLastTick + (delta or 0)

        if sinceLastTick >= 0.5 then
            sinceLastTick = 0
            self:OnTimerTick()
        end

    end)

    self.TickFrame = tickFrame

end

-------------------------------------------------
-- Reset Settings To Defaults
--
-- Mutates the existing Settings table in place
-- (rather than replacing it) so the options panel's
-- already-built widgets -- whose getValue/setValue
-- closures reference this exact table -- immediately
-- reflect the reset values without needing a UI reload.
-------------------------------------------------

function ImpLoot.LootMaster:ResetSettingsToDefaults()

    for key, value in pairs(self.Defaults) do
        self.Settings[key] = value
    end

end

-------------------------------------------------
-- Extract Item ID
-------------------------------------------------

function ImpLoot.LootMaster:ExtractItemID(itemLink)

    if not itemLink then
        return nil
    end

    local itemID = itemLink:match("item:(%d+)")

    return itemID and tonumber(itemID) or nil

end

-------------------------------------------------
-- Is Master Looter
-------------------------------------------------

function ImpLoot.LootMaster:IsMasterLooter()

    if not GetLootMethod then
        return false
    end

    local method, partyIndex, raidIndex = GetLootMethod()

    if method ~= "master" then
        return false
    end

    local playerName = UnitName("player")

    if raidIndex and raidIndex > 0 then

        local raidName = GetRaidRosterInfo and GetRaidRosterInfo(raidIndex)

        return raidName == playerName

    end

    if partyIndex and partyIndex > 0 then

        return UnitName("party" .. partyIndex) == playerName

    end

    -- partyIndex/raidIndex of 0 means the player themselves
    return true

end

-------------------------------------------------
-- Determine Mode
--
-- Loot Council takes priority over Soft Reserve if
-- an item somehow ends up tagged as both.
-------------------------------------------------

function ImpLoot.LootMaster:DetermineMode(itemID)

    local listName = ImpLoot.LootCouncil:GetActiveListName()

    if listName and ImpLoot.LootCouncil:IsCouncilItem(listName, itemID) then
        return "LootCouncil"
    end

    if #ImpLoot.SoftReserve:GetReserves(itemID) > 0 then
        return "SoftReserve"
    end

    return "OpenRoll"

end

-------------------------------------------------
-- Should Queue Item
--
-- The Minimum Quality setting only ever applies to an
-- item that isn't spoken for anywhere else in the addon.
-- Anything already on the priority list (Loot Council,
-- any mode) or Soft Reserved takes precedence over the
-- quality filter completely and always gets queued --
-- the filter only has a say for whatever's left, which
-- would otherwise just fall through to an unassigned
-- Open Roll. Below the configured minimum, those get
-- quietly skipped instead of ever reaching the queue;
-- at or above it, they're queued and handled exactly as
-- they always have been.
-------------------------------------------------

function ImpLoot.LootMaster:ShouldQueueItem(itemID, slotQuality)

    if self:DetermineMode(itemID) ~= "OpenRoll" then
        return true
    end

    local minimum = self.Settings.MinimumQuality or 0

    if minimum <= 0 then
        return true
    end

    local quality = slotQuality or self:GetItemQuality(itemID)

    if not quality then
        -- Unknown quality -- never silently hide an item
        -- we can't actually confirm falls below the bar.
        return true
    end

    return quality >= minimum

end

-------------------------------------------------
-- On Loot Opened
--
-- Scans every item slot in the loot window that just
-- opened. New items become new queue entries; items
-- already queued from a PREVIOUS opening of this same
-- corpse (e.g. it was closed and reopened) just get
-- their slot index refreshed rather than duplicated.
-------------------------------------------------

function ImpLoot.LootMaster:OnLootOpened()

    local corpseGUID = nil

    if UnitExists and UnitExists("target") then
        corpseGUID = UnitGUID("target")
    end

    if not corpseGUID then
        corpseGUID = "session-" .. tostring(self.NextQueueID)
    end

    -------------------------------------------------
    -- Auto-Clear On New Boss
    --
    -- Compares against the PREVIOUS corpse's GUID
    -- before it gets overwritten below. Re-opening the
    -- same corpse (closed and reopened to check for
    -- missed items) keeps the same GUID, so that never
    -- triggers a clear -- only a genuinely different
    -- corpse does.
    -------------------------------------------------

    if self.Settings.AutoClearOnNewBoss
    and self.CurrentCorpseGUID
    and self.CurrentCorpseGUID ~= corpseGUID
    and #self.Queue > 0 then

        self:ClearQueue()
        ImpLoot:Print("New boss detected -- loot queue cleared.")

    end

    self.CurrentCorpseGUID = corpseGUID

    local bossName = nil

    if UnitExists and UnitExists("target") then
        bossName = UnitName("target")
    end

    local numItems = GetNumLootItems and GetNumLootItems() or 0

    -------------------------------------------------
    -- Track which existing queue entries get matched
    -- THIS pass, so two genuinely separate copies of the
    -- same item dropping together (same corpse, same
    -- itemID, different loot slots) each get their own
    -- queue entry instead of the second slot silently
    -- overwriting the first's LootSlot. Reopening the
    -- SAME corpse later (a separate OnLootOpened call)
    -- still correctly upserts against those now-settled
    -- entries, since this tracking only exists for the
    -- duration of a single pass.
    -------------------------------------------------

    local matchedThisPass = {}

    for slot = 1, numItems do

        if LootSlotIsItem(slot) then

            local link = GetLootSlotLink(slot)
            local itemID = self:ExtractItemID(link)

            if itemID then

                local _, _, _, _, slotQuality = GetLootSlotInfo(slot)

                if self:ShouldQueueItem(itemID, slotQuality) then
                    local entry = self:AddToQueue(itemID, link, bossName, corpseGUID, slot, matchedThisPass)
                    matchedThisPass[entry.QueueID] = true
                end

            end

        end

    end

end

-------------------------------------------------
-- On Loot Closed
--
-- Every entry tied to the corpse that just closed
-- loses its slot index -- it can no longer be
-- assigned via the real API, only recorded for a
-- manual trade, unless this same corpse gets reopened
-- (handled by the upsert in AddToQueue/OnLootOpened).
-------------------------------------------------

function ImpLoot.LootMaster:OnLootClosed()

    for _, entry in ipairs(self.Queue) do

        if entry.CorpseGUID == self.CurrentCorpseGUID then

            entry.Assignable = false
            entry.LootSlot = nil

        end

    end

    ImpLoot.Events:Fire("LootQueueChanged")

end

-------------------------------------------------
-- Add To Queue (Upsert)
-------------------------------------------------

function ImpLoot.LootMaster:AddToQueue(itemID, itemLink, bossName, corpseGUID, lootSlot, matchedThisPass)

    for _, entry in ipairs(self.Queue) do

        if entry.ItemID == itemID
        and entry.CorpseGUID == corpseGUID
        and entry.State ~= "Resolved"
        and not (matchedThisPass and matchedThisPass[entry.QueueID]) then

            entry.LootSlot = lootSlot
            entry.Assignable = (lootSlot ~= nil)

            ImpLoot.Events:Fire("LootQueueChanged")

            return entry

        end

    end

    local entry = {

        QueueID = self.NextQueueID,
        ItemID = itemID,
        ItemLink = itemLink,
        BossName = bossName,
        CorpseGUID = corpseGUID,
        LootSlot = lootSlot,
        Assignable = (lootSlot ~= nil),

        Mode = self:DetermineMode(itemID),
        State = "Pending",

        Rolls = {},
        Winner = nil,
        TradeOnly = false,

    }

    self.NextQueueID = self.NextQueueID + 1

    table.insert(self.Queue, entry)

    ImpLoot.Events:Fire("LootQueueChanged")

    return entry

end

-------------------------------------------------
-- Add Manual Item
--
-- For anything that doesn't come through the loot
-- window on its own (currency, recipes, an item that
-- somehow didn't get picked up automatically): /il
-- <item link or name>. Accepts a pasted item link
-- (shift-click, always works) or a plain name (only
-- resolves if the client already knows about it --
-- e.g. it was just sitting in the loot window).
--
-- Goes into the exact same queue as corpse loot, with
-- no loot slot of its own -- so it behaves like any
-- other item whose corpse has already closed: trade-
-- only, never eligible for the real Master Loot API.
-------------------------------------------------

function ImpLoot.LootMaster:AddManualItem(text)

    if not text or text == "" then
        return false, "Usage: /il <item link or name>"
    end

    local itemID = self:ExtractItemID(text)
    local itemLink = itemID and text or nil

    if not itemID then

        local name, link = GetItemInfo(text)

        if link then
            itemLink = link
            itemID = self:ExtractItemID(link)
        end

    end

    if not itemID then

        return false,
            "Couldn't find \"" .. text .. "\" -- try pasting the item link " ..
            "(shift-click it) instead of typing the name."

    end

    local bossName = nil

    if UnitExists and UnitExists("target") then
        bossName = UnitName("target")
    end

    local entry = self:AddToQueue(itemID, itemLink, bossName, nil, nil)

    if self.Settings.ManualItemAutoRoll then

        local ok, message = self:AnnounceItem(entry.QueueID)

        if ok then
            return true, "Started the roll for " .. itemLink .. "."
        end

        -- Announcing failed for some reason (e.g. already
        -- rolling/resolved) -- the item's still safely in
        -- the queue either way, so fall through to the
        -- normal "added to the queue" message below rather
        -- than leaving the person with no feedback at all.

    end

    return true, "Added " .. itemLink .. " to the loot queue."

end

-------------------------------------------------
-- Get Queue / Get Entry / Remove
-------------------------------------------------

function ImpLoot.LootMaster:GetQueue()
    return self.Queue
end

function ImpLoot.LootMaster:GetEntry(queueID)

    for _, entry in ipairs(self.Queue) do

        if entry.QueueID == queueID then
            return entry
        end

    end

    return nil

end

function ImpLoot.LootMaster:RemoveFromQueue(queueID)

    for i, entry in ipairs(self.Queue) do

        if entry.QueueID == queueID then

            table.remove(self.Queue, i)

            ImpLoot.Events:Fire("LootQueueChanged")

            return true

        end

    end

    return false

end

function ImpLoot.LootMaster:ClearQueue()
    self.Queue = {}
    self.ActiveRollQueueID = nil
    ImpLoot.Events:Fire("LootQueueChanged")
end

-------------------------------------------------
-- Format Reserver List
--
-- "Jayallday (x3), Testing" -- based on who's still
-- actually eligible to roll (remaining slots), not
-- the raw import list, so an already-excluded winner
-- never shows as if they can still roll.
-------------------------------------------------

function ImpLoot.LootMaster:FormatReserverList(itemID)

    local slots = ImpLoot.SoftReserve:GetRemainingSlots(itemID)

    -------------------------------------------------
    -- Absent Reservers Aren't Shown Here
    --
    -- Someone who reserved an item but isn't actually
    -- in the raid wasn't there for the kill and isn't
    -- eligible for the loot, so there's no reason to
    -- list them in what the loot master sees -- unlike
    -- the chat announcement, which marks them instead
    -- (see FormatReserverListForAnnouncement), this is
    -- purely about who can actually win it.
    -------------------------------------------------

    local presentSlots = {}

    for _, slot in ipairs(slots) do

        if self:IsPlayerPresent(slot.Player) then
            table.insert(presentSlots, slot)
        end

    end

    if #presentSlots == 0 then
        return "No SoftRes"
    end

    local counts = {}
    local order = {}

    for _, slot in ipairs(presentSlots) do

        if not counts[slot.Player] then
            counts[slot.Player] = 0
            table.insert(order, slot.Player)
        end

        counts[slot.Player] = counts[slot.Player] + 1

    end

    local parts = {}

    for _, player in ipairs(order) do

        if counts[player] > 1 then
            table.insert(parts, player .. " (x" .. counts[player] .. ")")
        else
            table.insert(parts, player)
        end

    end

    return self:JoinWithAmpersand(parts)

end

-------------------------------------------------
-- Format Reserver List For Announcement
--
-- The chat-facing counterpart to FormatReserverList:
-- everyone still gets named here (so people who were
-- about to sit out an item they reserved know why), but
-- anyone not actually in the raid is marked "- Absent"
-- rather than silently left off a message the whole
-- raid sees.
-------------------------------------------------

function ImpLoot.LootMaster:FormatReserverListForAnnouncement(itemID)

    local slots = ImpLoot.SoftReserve:GetRemainingSlots(itemID)

    if #slots == 0 then
        return "No SoftRes"
    end

    local counts = {}
    local order = {}

    for _, slot in ipairs(slots) do

        if not counts[slot.Player] then
            counts[slot.Player] = 0
            table.insert(order, slot.Player)
        end

        counts[slot.Player] = counts[slot.Player] + 1

    end

    local parts = {}

    for _, player in ipairs(order) do

        local label = player

        if counts[player] > 1 then
            label = label .. " (x" .. counts[player] .. ")"
        end

        if not self:IsPlayerPresent(player) then
            label = "(" .. label .. " - Absent)"
        end

        table.insert(parts, label)

    end

    return self:JoinWithAmpersand(parts)

end

-------------------------------------------------
-- Join With Ampersand
--
-- "Rad" / "Rad & Smeb" / "Rad, Smeb, & Mordy" --
-- comma-separated with an Oxford-comma "&" before
-- the last name.
-------------------------------------------------

function ImpLoot.LootMaster:JoinWithAmpersand(parts)

    if #parts == 0 then
        return ""
    elseif #parts == 1 then
        return parts[1]
    elseif #parts == 2 then
        return parts[1] .. " & " .. parts[2]
    end

    local allButLast = {}

    for i = 1, #parts - 1 do
        table.insert(allButLast, parts[i])
    end

    return table.concat(allButLast, ", ") .. " & " .. parts[#parts]

end

-------------------------------------------------
-- Get Reserver Name List
--
-- Unique remaining-eligible names, plain array (for
-- the addon broadcast) -- as opposed to
-- FormatReserverList's "Name (xN)" display text.
-------------------------------------------------

function ImpLoot.LootMaster:GetReserverNameList(itemID)

    local slots = ImpLoot.SoftReserve:GetRemainingSlots(itemID)
    local seen = {}
    local names = {}

    for _, slot in ipairs(slots) do

        if not seen[slot.Player] then
            seen[slot.Player] = true
            table.insert(names, slot.Player)
        end

    end

    return names

end

-------------------------------------------------
-- Announce Item
--
-- Sends the "here's who's reserved this" message,
-- then opens it for rolling and sends the "roll now"
-- message -- each independently toggleable/customizable
-- via Modules/Announcements.lua. Loot Council items
-- aren't announced this way; they use LC Vote instead
-- (not built yet).
-------------------------------------------------

-------------------------------------------------
-- Token Class Groupings
--
-- Standard WotLK tier token groups. Tokens
-- (Type == "TIER_TOKEN") have no Classes field of their
-- own, since any class in the group can turn them in --
-- which group a token belongs to comes from the group word
-- (Conqueror / Protector / Vanquisher) in its name, whether
-- worded "Vanquisher's Mark of..." or "Mantle of the Lost
-- Vanquisher". That matching lives in
-- SoftReserve:GetItemClasses, which reads this table; only
-- items flagged as tokens are read that way, so an ordinary
-- drop that happens to share one of those words is never
-- mistaken for a token.
-------------------------------------------------

local TOKEN_CLASS_GROUPS = {
    { Prefix = "Conqueror's ", Classes = { "Paladin", "Priest", "Warlock" } },
    { Prefix = "Protector's ", Classes = { "Warrior", "Hunter", "Shaman" } },
    { Prefix = "Vanquisher's ", Classes = { "Rogue", "Death Knight", "Mage", "Druid" } },
}

ImpLoot.LootMaster.TokenClassGroups = TOKEN_CLASS_GROUPS

function ImpLoot.LootMaster:AnnounceItem(queueID)

    local entry = self:GetEntry(queueID)

    if not entry then
        return false, "Item not found in queue."
    end

    local listName, councilItem

    if entry.Mode == "LootCouncil" then

        listName = ImpLoot.LootCouncil:GetActiveListName()
        councilItem = listName and ImpLoot.LootCouncil:GetItem(listName, entry.ItemID)

        if not (councilItem and councilItem.Mode == "Preselected") then
            return false, "Loot Council items use LC Vote, not Announce."
        end

    end

    local reserverNames = {}

    if entry.Mode == "SoftReserve" then
        reserverNames = self:GetReserverNameList(entry.ItemID)
    end

    if ImpLoot.Comms then

        ImpLoot.Comms:SendItemAnnounced(entry.ItemID, entry.Mode, reserverNames)

    end

    if entry.Mode == "SoftReserve" then

        ImpLoot.Announcements:Announce("SoftReserveAnnounced", {
            item = entry.ItemLink,
            reservers = self:FormatReserverListForAnnouncement(entry.ItemID),
        })

    elseif councilItem and councilItem.Mode == "Preselected" then

        local remaining = ImpLoot.LootCouncil:GetRemainingCandidates(listName, entry.ItemID)
        local names = {}

        for _, candidate in ipairs(remaining) do

            if candidate.Type == "Class" then
                table.insert(names, "Any " .. candidate.Value)
            else
                table.insert(names, candidate.Value)
            end

        end

        ImpLoot.Announcements:Announce("PreselectedAnnounced", {
            item = entry.ItemLink,
            players = self:JoinWithAmpersand(names),
            seconds = self.Settings.RollDuration,
        })

    else

        ImpLoot.Announcements:Announce("OpenRollAnnounced", {
            item = entry.ItemLink,
            seconds = self.Settings.RollDuration,
        })

    end

    local item = ImpLoot.Database:FindItemByID(entry.ItemID)

    -- Class-locked gear lists its own classes; tier tokens are
    -- worked out from their name (see SoftReserve:GetItemClasses)
    local classes = item and ImpLoot.SoftReserve:GetItemClasses(item)

    if classes and #classes > 0 then

        ImpLoot.Announcements:Announce("EligibleClasses", {
            item = entry.ItemLink,
            classes = table.concat(classes, ", "),
        })

    end

    self:StartRoll(queueID)

    return true

end

-------------------------------------------------
-- Call Vote
--
-- Broadcasts a ballot to every council member (they
-- each decide locally whether to show it, based on
-- their own membership). The item stays "Voting"
-- until the loot master assigns it manually from the
-- live tally -- there's no auto-finalize for votes.
-------------------------------------------------

function ImpLoot.LootMaster:CallVote(queueID)

    local entry = self:GetEntry(queueID)

    if not entry then
        return false, "Item not found in queue."
    end

    if entry.Mode ~= "LootCouncil" then
        return false, "Only Loot Council items can be voted on."
    end

    local listName = ImpLoot.LootCouncil:GetActiveListName()

    if not listName then
        return false, "No active Loot Council list."
    end

    local candidates = ImpLoot.LootCouncil:GetRemainingCandidates(listName, entry.ItemID)

    self.NextVoteID = (self.NextVoteID or 0) + 1
    local voteID = "V" .. self.NextVoteID

    entry.State = "Voting"
    entry.ActiveVoteID = voteID
    entry.Votes = {}

    ImpLoot.Announcements:Announce("LCVoteCalled", {
        item = entry.ItemLink,
    })

    if ImpLoot.Comms then
        ImpLoot.Comms:SendVoteCall(entry.ItemID, voteID, candidates)
    end

    ImpLoot.Events:Fire("LootQueueChanged")

    return true

end

-------------------------------------------------
-- Record Vote Cast
--
-- One vote per voter per vote ID -- a repeat cast from
-- the same person just overwrites their earlier one
-- rather than counting twice.
-------------------------------------------------

function ImpLoot.LootMaster:RecordVoteCast(voteID, voterName, candidateType, candidateValue)

    for _, entry in ipairs(self.Queue) do

        if entry.ActiveVoteID == voteID then

            entry.Votes[voterName] = {
                Type = candidateType,
                Value = candidateValue,
            }

            ImpLoot.Events:Fire("LootQueueChanged")

            return true

        end

    end

    return false

end

-------------------------------------------------
-- Get Vote Tally
--
-- Returns an ordered list of {Value=, Count=}, most
-- votes first.
-------------------------------------------------

function ImpLoot.LootMaster:GetVoteTally(queueID)

    local entry = self:GetEntry(queueID)

    if not entry or not entry.Votes then
        return {}
    end

    local counts = {}
    local types = {}
    local order = {}

    for _, vote in pairs(entry.Votes) do

        if not counts[vote.Value] then
            counts[vote.Value] = 0
            types[vote.Value] = vote.Type
            table.insert(order, vote.Value)
        end

        counts[vote.Value] = counts[vote.Value] + 1

    end

    local tally = {}

    for _, value in ipairs(order) do
        table.insert(tally, { Value = value, Type = types[value], Count = counts[value] })
    end

    table.sort(tally, function(a, b) return a.Count > b.Count end)

    return tally

end

-------------------------------------------------
-- Start / Stop Roll
--
-- Only one item can be actively rolling at a time --
-- WoW's roll messages don't reference an item, so
-- every incoming roll is attributed to whichever
-- item this points at. Starting a roll wipes any
-- previous standings for it (a fresh roll window).
-------------------------------------------------

function ImpLoot.LootMaster:StartRoll(queueID)

    local entry = self:GetEntry(queueID)

    if not entry then
        return false, "Item not found in queue."
    end

    if entry.Mode == "LootCouncil" then

        local listName = ImpLoot.LootCouncil:GetActiveListName()
        local councilItem = listName and ImpLoot.LootCouncil:GetItem(listName, entry.ItemID)

        if not (councilItem and councilItem.Mode == "Preselected") then
            return false, "Loot Council items are voted, not rolled."
        end

    end

    entry.State = "Rolling"
    entry.Rolls = {}

    if self.Settings.RollDuration and self.Settings.RollDuration > 0 then

        entry.RollEndTime = GetTime() + self.Settings.RollDuration

        entry.NextPeriodicAnnounceAt = self.Settings.RollDuration
            - self.Settings.PeriodicAnnounceInterval

        entry.CountdownAnnounced = {}

    else

        entry.RollEndTime = nil

    end

    self.ActiveRollQueueID = queueID

    ImpLoot.Events:Fire("LootQueueChanged")

    return true

end

function ImpLoot.LootMaster:StopRoll(queueID)

    if self.ActiveRollQueueID == queueID then
        self.ActiveRollQueueID = nil
    end

end

-------------------------------------------------
-- Get Raid Roster Names
-------------------------------------------------

function ImpLoot.LootMaster:GetRaidRosterNames()

    local names = {}

    local numRaid = 0

    if GetNumRaidMembers then
        numRaid = GetNumRaidMembers()
    end

    if numRaid > 0 then

        for i = 1, numRaid do

            local name = GetRaidRosterInfo(i)

            if name then
                table.insert(names, name)
            end

        end

    else

        table.insert(names, (UnitName("player")))

    end

    return names

end

-------------------------------------------------
-- Is Player Present
--
-- Whether a name belongs to someone currently in the
-- raid roster -- offline members still count (they're
-- still in the group, just disconnected; they might
-- reconnect before anything needs resolving), only
-- someone genuinely not in the raid at all doesn't.
-------------------------------------------------

function ImpLoot.LootMaster:IsPlayerPresent(playerName)

    for _, rosterName in ipairs(self:GetRaidRosterNames()) do

        if self:NamesMatch(rosterName, playerName) then
            return true
        end

    end

    return false

end

-------------------------------------------------
-- On Timer Tick
--
-- Handles the periodic "N seconds left" announcements,
-- the final countdown (5, 4, 3, 2, 1), and finalizing
-- the roll once time is up. Reads GetTime() itself
-- rather than an elapsed-time parameter, so it's
-- directly callable without a real game loop.
-------------------------------------------------

function ImpLoot.LootMaster:OnTimerTick()

    -- Fired unconditionally (even with no active roll) so
    -- the Loot Master window's per-row countdown numbers
    -- stay in sync -- including hiding a stale number once
    -- a roll ends, not just updating it while one's active.
    ImpLoot.Events:Fire("LootTimerTick")

    local queueID = self.ActiveRollQueueID

    if not queueID then
        return
    end

    local entry = self:GetEntry(queueID)

    if not entry or not entry.RollEndTime then
        return
    end

    local remaining = entry.RollEndTime - GetTime()

    if remaining <= 0 then
        self:FinalizeRoll(queueID)
        return
    end

    -- Lightweight signal, separate from LootQueueChanged --
    -- lets the window update just the visible countdown
    -- number in place, without rebuilding the whole row
    -- list every half second.
    ImpLoot.Events:Fire("LootTimerTick", queueID, remaining)

    local remainingRounded = math.ceil(remaining)

    -------------------------------------------------
    -- Final Countdown
    -------------------------------------------------

    if remainingRounded <= self.Settings.FinalCountdownThreshold
    and remainingRounded >= 1 then

        if not entry.CountdownAnnounced[remainingRounded] then

            entry.CountdownAnnounced[remainingRounded] = true

            ImpLoot.Announcements:Announce("RollCountdown", {
                item = entry.ItemLink,
                count = remainingRounded,
            })

        end

        return

    end

    -------------------------------------------------
    -- Periodic "N Seconds Left"
    -------------------------------------------------

    if self.Settings.PeriodicAnnounceInterval > 0
    and entry.NextPeriodicAnnounceAt
    and remainingRounded <= entry.NextPeriodicAnnounceAt then

        ImpLoot.Announcements:Announce("RollTimeRemaining", {
            item = entry.ItemLink,
            seconds = remainingRounded,
        })

        entry.NextPeriodicAnnounceAt =
            entry.NextPeriodicAnnounceAt - self.Settings.PeriodicAnnounceInterval

        if entry.NextPeriodicAnnounceAt <= self.Settings.FinalCountdownThreshold then
            entry.NextPeriodicAnnounceAt = nil
        end

    end

end

-------------------------------------------------
-- Finalize Roll
--
-- Always stops accepting new rolls once time is up.
-- Whether it goes on to auto-assign is a separate
-- setting -- if it's off, the item just sits ready
-- for the loot master to Assign manually.
-------------------------------------------------

function ImpLoot.LootMaster:FinalizeRoll(queueID, isManualStop)

    local entry = self:GetEntry(queueID)

    if not entry then
        return
    end

    self:StopRoll(queueID)

    entry.RollEndTime = nil
    entry.State = "RollComplete"

    ImpLoot.Events:Fire("LootQueueChanged")

    -------------------------------------------------
    -- Winner Announcement
    --
    -- Announced here, the moment the countdown actually
    -- ends -- not in Assign(), which may not get called
    -- until much later (manual assignment, or Auto
    -- Finalize/Auto Assign turned off). Loot Council
    -- items never reach this function at all (they
    -- resolve via LC Vote, not a roll timer), so their
    -- own announcement still happens in Assign().
    -------------------------------------------------

    local topRoll = self:GetTopRoll(queueID)

    if topRoll then

        ImpLoot.Announcements:Announce("WinnerAnnounced", {
            item = entry.ItemLink,
            winner = topRoll.Player,
            roll = tostring(topRoll.Roll),
            range = tostring(topRoll.Min) .. "-" .. tostring(topRoll.Max),
        })

    end

    -------------------------------------------------
    -- Manually Clicking Stop Always Resolves The Roll
    --
    -- A deliberate, active decision to end the roll
    -- right now -- unlike the timer running out on its
    -- own, assigning to whoever's currently winning
    -- doesn't wait on the Auto Finalize/Auto Assign
    -- settings (those two only describe unattended
    -- behaviour for a natural timeout). If nobody
    -- rolled at all, it still falls through to the
    -- disenchanter check below, same as an unattended
    -- timeout would.
    -------------------------------------------------

    if isManualStop then

        -------------------------------------------------
        -- Stop Also Finalizes Any Sibling Still Rolling
        --
        -- Clicking Stop only ever directly targets the
        -- one row it's clicked on -- for a multi-copy
        -- Soft Reserve group (see ExecuteGroupRoll),
        -- every copy was started rolling together, but
        -- without this they'd only ever get *stopped*
        -- together if the loot master happened to click
        -- Stop on each one separately. Left alone, a
        -- sibling copy would just sit on its own Stop
        -- button indefinitely once this one's already
        -- resolved -- no Assign button, no auto-assign,
        -- nothing, until someone noticed and clicked it
        -- too. Recursing here finalizes each one exactly
        -- as if Stop had been clicked on it directly,
        -- including its own winner announcement and
        -- assignment -- and since each call only ever
        -- looks at siblings still in "Rolling" (this one
        -- is "RollComplete" by the time it loops back
        -- around), it can't re-process the same entry
        -- twice or loop forever.
        -------------------------------------------------

        for _, sibling in ipairs(self:GetSiblingEntries(entry)) do

            if sibling.State == "Rolling" then
                self:FinalizeRoll(sibling.QueueID, true)
            end

        end

        if topRoll then
            self:RequestAssign(queueID, topRoll.Player)
            return
        end

    end

    if not isManualStop and not self.Settings.AutoFinalizeOnTimeout then
        return
    end

    if not topRoll then

        local disenchanter = ImpLoot.LootCouncil:GetActiveDisenchanter(
            self:GetRaidRosterNames()
        )

        if disenchanter then

            ImpLoot.Announcements:Announce("NoRollsDisenchant", {
                item = entry.ItemLink,
            })

            self:RequestAssign(queueID, disenchanter)

        end

        return

    end

    if self.Settings.AutoAssignToRollWinner then
        self:RequestAssign(queueID, topRoll.Player)
    end

end

function ImpLoot.LootMaster:GetActiveRollQueueID()
    return self.ActiveRollQueueID
end

-------------------------------------------------
-- Get Roll Type
-------------------------------------------------

function ImpLoot.LootMaster:GetRollType(minRoll, maxRoll)

    -- Standard WotLK convention: /roll 1-100 is Main Spec,
    -- anything with a top end below 100 (the Off-Spec Roll
    -- button rolls 1-99) is Off Spec.
    if maxRoll and maxRoll < 100 then
        return "OS"
    end

    return "MS"

end

-------------------------------------------------
-- Get Max Rolls For Player
--
-- Open Roll: everyone gets exactly one roll. Soft
-- Reserve: as many rolls as they have remaining
-- reserved slots on this item (so a triple reserve
-- gets three). Loot Council items aren't rolled at
-- all.
-------------------------------------------------

function ImpLoot.LootMaster:GetMaxRollsForPlayer(entry, playerName)

    if entry.Mode == "OpenRoll" then
        return 1
    end

    if entry.Mode == "LootCouncil" then

        local listName = ImpLoot.LootCouncil:GetActiveListName()
        local councilItem = listName and ImpLoot.LootCouncil:GetItem(listName, entry.ItemID)

        if not (councilItem and councilItem.Mode == "Preselected") then
            return 0
        end

        local remaining = ImpLoot.LootCouncil:GetRemainingCandidates(listName, entry.ItemID)

        for _, candidate in ipairs(remaining) do

            if candidate.Type == "Player" and self:NamesMatch(candidate.Value, playerName) then
                return 1
            end

        end

        return 0

    end

    if entry.Mode ~= "SoftReserve" then
        return 0
    end

    local slots = ImpLoot.SoftReserve:GetRemainingSlots(entry.ItemID)
    local count = 0

    for _, slot in ipairs(slots) do

        if slot.Player == playerName then
            count = count + 1
        end

    end

    return count

end

-------------------------------------------------
-- On Chat Msg System
--
-- Parses WoW's own roll system message and routes it
-- to whichever item is currently open for rolling.
-------------------------------------------------

function ImpLoot.LootMaster:OnChatMsgSystem(msg)

    if not self.ActiveRollQueueID then
        return
    end

    local player, roll, minRoll, maxRoll = msg:match(ROLL_PATTERN)

    if not player then
        return
    end

    self:ProcessRoll(
        self.ActiveRollQueueID,
        player,
        tonumber(roll),
        tonumber(minRoll),
        tonumber(maxRoll)
    )

end

-------------------------------------------------
-- Process Roll
--
-- Rejects the roll (rather than counting it) if the
-- item isn't actively rolling, the roll is a 0 (i.e.
-- someone typed "pass"), or the player has no
-- eligible rolls left for this item.
-------------------------------------------------

function ImpLoot.LootMaster:ProcessRoll(queueID, playerName, rollValue, minRoll, maxRoll)

    local entry = self:GetEntry(queueID)

    if not entry or entry.State ~= "Rolling" then
        return false, "No active roll for this item."
    end

    if rollValue == 0 then
        return false, "Rolls of 0 don't count."
    end

    -------------------------------------------------
    -- Only The Two Standard Ranges Count
    --
    -- /roll 1-100 (Main Spec) or /roll 1-99 (the
    -- addon's own Off Spec Roll button, and the
    -- standard convention for it) -- anything else
    -- (a typo'd range, a custom /roll someone made up)
    -- is silently ignored rather than being treated as
    -- a legitimate participant in the standings.
    -------------------------------------------------

    if maxRoll ~= 100 and maxRoll ~= 99 then
        return false, "Only /roll 1-100 or 1-99 count -- that roll was ignored."
    end

    local maxAllowed = self:GetMaxRollsForPlayer(entry, playerName)

    local existingCount = 0

    for _, roll in ipairs(entry.Rolls) do

        if roll.Player == playerName then
            existingCount = existingCount + 1
        end

    end

    if existingCount >= maxAllowed then

        return false,
            playerName .. " has no eligible rolls remaining for this item."

    end

    -------------------------------------------------
    -- Two Copies, One Roll
    --
    -- When the same item drops twice from the same
    -- corpse (two separate queue entries -- see
    -- AddToQueue), players naturally roll ONCE for a
    -- shot at either copy, not once per copy. Mirror
    -- the same roll into any sibling entry that's also
    -- still actively rolling, so both entries' standings
    -- stay identical throughout the roll period.
    -------------------------------------------------

    local siblings = self:GetSiblingEntries(entry)

    local function RecordRollOn(targetEntry)

        table.insert(targetEntry.Rolls, {
            Player = playerName,
            Roll = rollValue,
            Type = self:GetRollType(minRoll, maxRoll),
            Min = minRoll,
            Max = maxRoll,
        })

        table.sort(targetEntry.Rolls, function(a, b)

            -- Main Spec rolls always outrank Off Spec rolls,
            -- regardless of the actual number rolled -- an
            -- 87 on an Off Spec roll (1-99) must never beat
            -- a 45 on a Main Spec roll (1-100). Only compare
            -- the raw roll value once both sides are the
            -- same type.
            if a.Type ~= b.Type then
                return a.Type == "MS"
            end

            return a.Roll > b.Roll

        end)

    end

    RecordRollOn(entry)

    for _, sibling in ipairs(siblings) do

        if sibling.State == "Rolling" then
            RecordRollOn(sibling)
        end

    end

    ImpLoot.Events:Fire("LootQueueChanged")

    return true

end

-------------------------------------------------
-- Get Sibling Entries
--
-- Other queue entries for the exact same item dropped
-- from the exact same corpse -- i.e. two or more copies
-- that appeared together in one loot window. Used to
-- keep roll standings in sync across copies and to
-- exclude an already-assigned winner from the others'
-- standings.
-------------------------------------------------

function ImpLoot.LootMaster:GetSiblingEntries(entry)

    local siblings = {}

    for _, other in ipairs(self.Queue) do

        if other.QueueID ~= entry.QueueID
        and other.ItemID == entry.ItemID
        and other.CorpseGUID == entry.CorpseGUID then

            table.insert(siblings, other)

        end

    end

    return siblings

end

-------------------------------------------------
-- Get Copy Group
--
-- Every still-Pending entry for the exact same item
-- from the exact same corpse, itself included -- the
-- full set of copies a Soft Reserve multi-copy
-- decision (see GetMultiCopyDecision) needs to reason
-- about together. Once a copy leaves Pending (it's
-- rolling, or already resolved), it's no longer part
-- of a decision still being made about the others.
-------------------------------------------------

function ImpLoot.LootMaster:GetCopyGroup(entry)

    local group = {}

    for _, other in ipairs(self.Queue) do

        if other.ItemID == entry.ItemID
        and other.CorpseGUID == entry.CorpseGUID
        and other.State == "Pending" then

            table.insert(group, other)

        end

    end

    return group

end

-------------------------------------------------
-- Get Multi-Copy Decision
--
-- For a Soft Reserve item with more than one Pending
-- copy from the same corpse, works out which of two
-- outcomes applies by comparing distinct reservers to
-- the number of copies -- reusing the exact same
-- comparison the Sole Reserver shortcut already makes,
-- just no longer limited to 1-vs-1:
--
--   reservers <= copies -> "DirectAssign": no roll
--   needed at all, one copy per reserver. Any leftover
--   copies (more copies than reservers) fall back to
--   plain Open Roll, same as an unreserved item.
--
--   reservers > copies -> "GroupRoll": every copy in
--   the group needs to be rolled for together, as one
--   combined event rather than separate per-copy
--   announcements.
--
-- Returns nil when there's nothing special to decide:
-- not Soft Reserve mode, only one copy, no reservers
-- at all, or AllowMultipleReserves is on (that setting
-- means each copy is deliberately handled on its own --
-- see SoftReserve.lua).
-------------------------------------------------

function ImpLoot.LootMaster:GetMultiCopyDecision(entry)

    if entry.Mode ~= "SoftReserve" then
        return nil
    end

    if ImpLoot.SoftReserve:GetSettings().AllowMultipleReserves then
        return nil
    end

    local group = self:GetCopyGroup(entry)

    if #group <= 1 then
        return nil
    end

    local reservers = ImpLoot.SoftReserve:GetPresentReservers(entry.ItemID)

    if #reservers == 0 then
        return nil
    end

    if #reservers <= #group then

        return {
            Type = "DirectAssign",
            Group = group,
            Reservers = reservers,
        }

    end

    return {
        Type = "GroupRoll",
        Group = group,
    }

end

-------------------------------------------------
-- Execute Direct Assign
--
-- The "reservers <= copies" outcome of a multi-copy
-- decision: one copy per reserver, no roll, one
-- combined announcement naming everyone who's getting
-- one. Any copies left over once every reserver has
-- one (more copies than reservers) are released to
-- plain Open Roll -- handled from there exactly like
-- any other unreserved item, not auto-announced here.
-------------------------------------------------

function ImpLoot.LootMaster:ExecuteDirectAssign(decision)

    local group = decision.Group
    local reservers = decision.Reservers

    for i = #reservers + 1, #group do
        group[i].Mode = "OpenRoll"
    end

    ImpLoot.Announcements:Announce("MultiCopyDirectAssigned", {
        item = group[1].ItemLink,
        count = tostring(#reservers),
        winners = self:JoinWithAmpersand(reservers),
    })

    for i, reserver in ipairs(reservers) do
        self:RequestAssign(group[i].QueueID, reserver)
    end

end

-------------------------------------------------
-- Execute Group Roll
--
-- The "reservers > copies" outcome: every copy in the
-- group needs a roll, but as one combined event -- a
-- single announcement and every copy's timer starting
-- together, rather than the loot master having to
-- click Announce on each copy separately (which is
-- exactly how a copy could be left un-announced with
-- no roll data of its own, sitting out the whole roll
-- period). Rolls mirroring across copies and excluding
-- an assigned winner from the others' standings is
-- unchanged, existing behaviour (see ProcessRoll and
-- Assign) -- this only fixes how the group gets
-- started in the first place.
-------------------------------------------------

function ImpLoot.LootMaster:ExecuteGroupRoll(decision)

    local group = decision.Group

    -- AnnounceItem handles the chat message, the addon-
    -- to-addon sync, and the eligible-classes follow-up
    -- (if any) -- all identical for every copy since they
    -- share the same ItemID/Mode/reserver list, so that
    -- only needs to happen once, via the first copy.
    -- Every other copy just needs its own timer started.

    self:AnnounceItem(group[1].QueueID)

    for i = 2, #group do
        self:StartRoll(group[i].QueueID)
    end

end

-------------------------------------------------
-- Standings

-------------------------------------------------

function ImpLoot.LootMaster:GetStandings(queueID)

    local entry = self:GetEntry(queueID)

    if not entry then
        return {}
    end

    return entry.Rolls

end

function ImpLoot.LootMaster:GetTopRoll(queueID)
    return self:GetStandings(queueID)[1]
end

-------------------------------------------------
-- Names Match
--
-- Strips a realm suffix ("Name-Realm") before
-- comparing, since candidate names and roll names
-- don't always carry one consistently.
-------------------------------------------------

function ImpLoot.LootMaster:NamesMatch(a, b)

    if not a or not b then
        return false
    end

    local shortA = a:match("^([^%-]+)") or a
    local shortB = b:match("^([^%-]+)") or b

    return shortA == shortB

end

-------------------------------------------------
-- Find Candidate Index
--
-- Master Loot's candidate list is shared across every
-- item in the current loot window (eligibility is
-- about loot range, not the specific item) -- so this
-- doesn't take a slot parameter, matching the real API.
-------------------------------------------------

function ImpLoot.LootMaster:FindCandidateIndex(winnerName)

    if not GetMasterLootCandidate then
        return nil
    end

    local numMembers = 0

    if GetNumRaidMembers then
        numMembers = GetNumRaidMembers()
    end

    for i = 1, numMembers do

        local candidateName = GetMasterLootCandidate(i)

        if candidateName and self:NamesMatch(candidateName, winnerName) then
            return i
        end

    end

    return nil

end

-------------------------------------------------
-- Assign
--
-- Calls the real Master Loot API when the item's
-- corpse is still open and the winner is a valid
-- candidate; otherwise just records the winner so the
-- item can be traded manually later. Either path is
-- "Assign" from the loot master's point of view.
-------------------------------------------------

function ImpLoot.LootMaster:RecordWinForExclusion(entry, winnerName)

    if entry.Mode == "SoftReserve" then

        ImpLoot.SoftReserve:RecordWin(entry.ItemID, winnerName)

    elseif entry.Mode == "LootCouncil" then

        local listName = ImpLoot.LootCouncil:GetActiveListName()

        if not listName then
            return
        end

        local remaining = ImpLoot.LootCouncil:GetRemainingCandidates(listName, entry.ItemID)

        for _, candidate in ipairs(remaining) do

            if candidate.Type == "Player" and candidate.Value == winnerName then

                ImpLoot.LootCouncil:RecordWin(listName, entry.ItemID, "Player", winnerName, winnerName)

                return

            end

        end

        -- A Class-type slot needs the winner's class, which isn't
        -- derivable from just a name here -- the vote UI (not built
        -- yet) will need to supply that explicitly when it resolves
        -- a Class candidate.

    end

end

-------------------------------------------------
-- Log Resolution / Get Log / Clear Log
--
-- Every client (loot master or not) builds its own
-- copy of this log -- the loot master logs locally at
-- the moment of resolution and also broadcasts it, so
-- the raid leader (if a different person) gets one
-- too, and anyone else running the addon who's curious.
-------------------------------------------------

function ImpLoot.LootMaster:LogResolution(itemID, winnerName, bossName, mode, resultLabel)

    local now = time and time() or 0

    -------------------------------------------------
    -- Guard Against An Exact Duplicate
    --
    -- The same item, winner and boss logged again
    -- within a few seconds of the most recent entry is
    -- never a second, genuine resolution -- it's the
    -- same one arriving twice (an addon message echo,
    -- a double-fired event, etc). Checking only the
    -- most recent entry, not the whole log, is
    -- deliberate: two separate, real wins of the same
    -- item by the same person (different raid nights,
    -- or legitimately winning two copies under Allow
    -- Multiple Reserves) must still both be recorded.
    -------------------------------------------------

    local lastEntry = self.Log[#self.Log]

    if lastEntry
    and lastEntry.ItemID == itemID
    and lastEntry.Winner == winnerName
    and lastEntry.BossName == bossName
    and (now - lastEntry.Timestamp) < 5 then

        return

    end

    table.insert(self.Log, {
        ItemID = itemID,
        Winner = winnerName,
        BossName = bossName,
        Mode = mode,
        ResultLabel = resultLabel,
        Timestamp = now,
    })

end

-------------------------------------------------
-- Get Result Label
--
-- The short tag for the Summary window's Roll column:
-- "SR" for a Soft Reserve win, "LC" for Loot Council,
-- or the winner's own roll type (MS/OS) looked up from
-- the entry's own roll standings for an Open Roll win.
-- Blank if none of those apply (e.g. assigned with no
-- roll at all, or the winner's roll can't be found).
-------------------------------------------------

function ImpLoot.LootMaster:GetResultLabel(entry, winnerName)

    if entry.Mode == "SoftReserve" then
        return "SR"
    end

    if entry.Mode == "LootCouncil" then
        return "LC"
    end

    if entry.Rolls then

        for _, roll in ipairs(entry.Rolls) do

            if roll.Player == winnerName then
                return roll.Type
            end

        end

    end

    return ""

end

function ImpLoot.LootMaster:GetLog()
    return self.Log
end

function ImpLoot.LootMaster:ClearLog()
    self.Log = {}
    ImpLootDB.LootMasterLog = self.Log
end

function ImpLoot.LootMaster:Assign(queueID, winnerName)

    local entry = self:GetEntry(queueID)

    if not entry then
        return false, "Item not found in queue."
    end

    self:RecordWinForExclusion(entry, winnerName)

    -------------------------------------------------
    -- Two Copies, One Roll: Exclude The Winner From
    -- The Other Copy's Standings
    --
    -- Once this copy is assigned, any sibling entry
    -- (the same item dropped from the same corpse,
    -- still unresolved) needs the winner's roll(s)
    -- removed from ITS standings too -- otherwise its
    -- own top roll would just be the same person again,
    -- instead of correctly becoming whoever was next in
    -- line.
    -------------------------------------------------

    for _, sibling in ipairs(self:GetSiblingEntries(entry)) do

        if sibling.State ~= "Resolved" then

            for i = #sibling.Rolls, 1, -1 do

                if sibling.Rolls[i].Player == winnerName then
                    table.remove(sibling.Rolls, i)
                end

            end

        end

    end

    local resultMessage

    if entry.Assignable
    and entry.LootSlot
    and self:IsMasterLooter() then

        local candidateIndex = self:FindCandidateIndex(winnerName)

        if candidateIndex then

            GiveMasterLoot(entry.LootSlot, candidateIndex)

            entry.Winner = winnerName
            entry.State = "Resolved"

            resultMessage = "Assigned via Master Loot."

        end

    end

    if not resultMessage then

        entry.Winner = winnerName
        entry.State = "Resolved"
        entry.TradeOnly = true

        resultMessage = "Recorded -- trade this item to " .. winnerName .. "."

    end

    -------------------------------------------------
    -- Winner Announcement
    --
    -- Only for Loot Council items -- Open Roll and Soft
    -- Reserve items already got their WinnerAnnounced
    -- the moment the roll ended, in FinalizeRoll, not
    -- here (Assign for those can happen much later --
    -- manual assignment, or Auto Assign turned off).
    -------------------------------------------------

    if entry.Mode == "LootCouncil" then

        local listName = ImpLoot.LootCouncil:GetActiveListName()
        local councilItem = listName and ImpLoot.LootCouncil:GetItem(listName, entry.ItemID)

        if councilItem and councilItem.Mode == "Funnel" then

            -------------------------------------------------
            -- Funnel Assignment Announcement
            --
            -- No roll or vote happened here -- a plain
            -- "assigned to" message fits better than the
            -- roll-flavoured WinnerAnnounced text.
            -------------------------------------------------

            ImpLoot.Announcements:Announce("FunnelAssigned", {
                item = entry.ItemLink,
                player = winnerName,
            })

        else

            local winnerRoll = nil

            for _, roll in ipairs(entry.Rolls) do

                if roll.Player == winnerName then
                    winnerRoll = roll
                    break
                end

            end

            local rollText = "N/A"
            local rangeText = "N/A"

            if winnerRoll then
                rollText = tostring(winnerRoll.Roll)
                rangeText = tostring(winnerRoll.Min) .. "-" .. tostring(winnerRoll.Max)
            end

            ImpLoot.Announcements:Announce("WinnerAnnounced", {
                item = entry.ItemLink,
                winner = winnerName,
                roll = rollText,
                range = rangeText,
            })

        end

    end

    local resultLabel = self:GetResultLabel(entry, winnerName)

    self:LogResolution(entry.ItemID, winnerName, entry.BossName, entry.Mode, resultLabel)

    if ImpLoot.Comms then

        ImpLoot.Comms:SendResolved(
            entry.ItemID, winnerName, entry.BossName, entry.Mode, resultLabel
        )

    end

    ImpLoot.Events:Fire("LootQueueChanged")

    return true, resultMessage

end
